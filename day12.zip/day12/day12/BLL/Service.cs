using K4os.Compression.LZ4.Streams;

namespace BLL;
using BOL;
using DAL.connected;

public class Service
{
    public List<Footwear> display()
    {
        List<Footwear> lst = new List<Footwear>();
        DBManager db = new DBManager();
        lst = db.getAllData();
        return lst;
    }
}