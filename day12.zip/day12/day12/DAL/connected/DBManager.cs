namespace DAL.connected;
using BOL;
using MySql.Data.MySqlClient;

public class DBManager
{
    public static string cn = @"server=192.168.10.150;port=3306;user=dac27;password=welcome;database=dac27";
    public List<Footwear> getAllData()
    {
        List<Footwear> lst = new List<Footwear>();
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = cn;
        string query = "select * from footwear";
        MySqlCommand cmd = new MySqlCommand(query, con);
        try
        {
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string name = reader["brand"].ToString();
                int size = int.Parse(reader["size"].ToString());
                int price = int.Parse(reader["price"].ToString());

                Footwear f = new Footwear(name, size, price);
                lst.Add(f);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            con.Close();
        }
        return lst;
    }

    public bool Insert(string brand, int size, int price)
    {
        bool status = false;

        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = cn;
        string query = "insert into footwear values(@brand, @size, @price)";
        MySqlCommand cmd = new MySqlCommand(query, con);
        try
        {
            con.Open();
            cmd.Parameters.AddWithValue("@brand", brand);
            cmd.Parameters.AddWithValue("@size", size);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.ExecuteNonQuery();
            status = true;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            con.Close();
        }

        return status;
    }
    public bool Update(string brand, int size, int price)
    {
        bool status = false;
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = cn;
        string query = "update footwear set brand = @brand , size = @size where price = @price";
        // Console.WriteLine(brand1);
        MySqlCommand cmd = new MySqlCommand(query, con);
        try
        {
            con.Open();
            cmd.Parameters.AddWithValue("@brand", brand);
            cmd.Parameters.AddWithValue("@size", size);
            cmd.Parameters.AddWithValue("@price", price);


            cmd.ExecuteNonQuery();
            status = true;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            con.Close();
        }
        return status;
    }

    public bool DeleteById(int price)
    {
        bool status = false;
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = cn;
        //con.ConnectionString = "server=localhost;port=3306;user=root;password=Bhavesh.20@;database=dotnet";
        string query = "delete from footwear where price=@price";
        MySqlCommand cmd = new MySqlCommand(query, con);
        try
        {
            con.Open();
            cmd.Parameters.AddWithValue("@price", price);
            cmd.ExecuteNonQuery();
            status = true;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            con.Close();
        }
        return status;
    }
}