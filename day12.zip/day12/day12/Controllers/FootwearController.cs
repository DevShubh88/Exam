using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using day12.Models;
using BLL;
using DAL.connected;
using BOL;

namespace day12.Controllers;

public class FootwearController : Controller
{
    private readonly ILogger<FootwearController> _logger;

    public FootwearController(ILogger<FootwearController> logger)
    {
        _logger = logger;
    }

    public IActionResult Show()
    {
        Service s = new Service();
        var lst = s.display();
        ViewData["data"] = lst;
        return View();
    }
    [HttpGet]
    public IActionResult Insert()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Insert(string Brand, int Size, int Price)
    {
        DBManager db = new DBManager();
        bool status = db.Insert(Brand, Size, Price);
        if (status)
        {
            return RedirectToAction("Show");
        }
        else
        {
            return View();
        }
    }
    [HttpGet]
    public IActionResult Update(int price)
    {

        DBManager db = new DBManager();
        List<Footwear> lst = db.getAllData();
        // Console.WriteLine(id);
        var f = lst.Find((Footwear) => Footwear.price == price);
        return View(f);
    }
    [HttpPost]
    public IActionResult Update(string Brand, int Size, int Price)
    {
        DBManager db = new DBManager();
        bool status = db.Update(Brand, Size, Price);
        if (status)
        {
            return RedirectToAction("Show");
        }
        else
        {
            return RedirectToAction("Error1");
        }
    }
    public IActionResult Error1()
    {
        return View();
    }

    // [HttpPost]
    // public IActionResult DeleteById(int price)
    // {
    //     DBManager db = new DBManager();
    //     bool status = db.DeleteById(price);
    //     if (status)
    //     {
    //         return RedirectToAction("Show");
    //     }
    //     else
    //     {
    //         return RedirectToAction("Error1");
    //     }
    // }
 [HttpGet]
    public IActionResult Delete(int price)
    {

        DBManager db = new DBManager();
        bool status = db.DeleteById(price);
        if (status)
        {
            return RedirectToAction("Show");
        }
        else
        {
            return RedirectToAction("Error1");
        }
    }
    }