namespace BOL;
public class Footwear
{
    public string brand { get; set; }
    public int size { get; set; }
    public int price { get; set; }
    public Footwear(string name, int size, int price)
    {
        this.brand = name;
        this.size = size;
        this.price = price;
    }
}