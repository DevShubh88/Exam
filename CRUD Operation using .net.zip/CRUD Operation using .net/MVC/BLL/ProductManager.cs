﻿namespace BLL;
using System.Collections.Generic;
using BOL;

using DAL;

public class ProductManager
{
    public List<Product> ShowAll()
    {
        List <Product> allProducts=new List<Product>();

      allProducts= DBManager.GetAllPro();
        return allProducts;
    }

}
